inputEl = document.getElementById('input')

todosUL = document.getElementById('todos')

loadTodos()

function loadTodos() {
    todos = JSON.parse(localStorage.getItem('todos'))

    if (todos != undefined) {
        todos.forEach(todo => addTodo(todo.text, todo.isCompleted))


    }
}


inputEl.addEventListener("keyup", function (event) {
   
    if (event.code == 'Enter') {
        
        addTodo(inputEl.value, false)
    }
})

function addTodo(todoText, isCompleted) {

  
    todoEl = document.createElement('li')

    todoEl.innerText = todoText

    if (isCompleted) {
        todoEl.classList.add('completed')
    }
    


    todoEl.addEventListener('click', (e) => {
    
        clickedElement = e.target

        clickedElement.classList.toggle('completed')

        updateLocalStorage()
    })

    
    todoEl.addEventListener('contextmenu', (e) => {

        e.preventDefault()

        
        clickedElement = e.target
        
        clickedElement.remove()

        
        updateLocalStorage()
    })

    
    todosUL.appendChild(todoEl)

    inputEl.value = ''

    updateLocalStorage()

    function updateLocalStorage() {
        todosEl = document.querySelectorAll('li');

        todos = [];

        todosEl.forEach(todoEl => {
            todo = {
                text : todoEl.innerText,
                isCompleted : todoEl.classList.contains('completed')
            }
        })

        todos.push(todo);

        localStorage.setItem('todos', JSON.stringify(todos));
    }

}